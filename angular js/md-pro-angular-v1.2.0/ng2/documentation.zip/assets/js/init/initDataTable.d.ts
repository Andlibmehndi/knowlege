declare function initDataTable():void;
export = initDataTable;
