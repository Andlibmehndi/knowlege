declare function initCharts():void;
export = initCharts;
