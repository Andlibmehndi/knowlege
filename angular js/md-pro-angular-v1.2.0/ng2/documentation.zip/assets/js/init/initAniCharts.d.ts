declare function initAniCharts():void;
export = initAniCharts;
