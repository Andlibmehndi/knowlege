import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'regular-table-cmp',
    templateUrl: 'regulartable.component.html'
})

export class RegularTableComponent implements OnInit{

    ngOnInit(){
    }
}
