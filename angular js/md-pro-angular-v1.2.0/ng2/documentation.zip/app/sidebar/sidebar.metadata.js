"use strict";
(function (MenuType) {
    MenuType[MenuType["BRAND"] = 0] = "BRAND";
    MenuType[MenuType["LEFT"] = 1] = "LEFT";
    MenuType[MenuType["RIGHT"] = 2] = "RIGHT";
})(exports.MenuType || (exports.MenuType = {}));
var MenuType = exports.MenuType;
//# sourceMappingURL=sidebar.metadata.js.map