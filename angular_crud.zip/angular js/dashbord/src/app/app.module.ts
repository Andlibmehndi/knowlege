import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import { headerComponent } from './header.component';
import { sidebarComponent } from './sidebar.component';
import { contentComponent } from './pdashboard/content.component';


@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent , headerComponent,sidebarComponent,contentComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
