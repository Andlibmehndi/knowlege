import { Component } from '@angular/core';

@Component({
  selector: 'nav-header',
  templateUrl : '../../nav_header.html',
})
export class headerComponent  { }
