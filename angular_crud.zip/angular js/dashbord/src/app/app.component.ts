import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
  <div class="main-panel" ><nav-header></nav-header>
  <my-content ></my-content></div>
  <sidebar></sidebar>
  `,
})
export class AppComponent  {  }
