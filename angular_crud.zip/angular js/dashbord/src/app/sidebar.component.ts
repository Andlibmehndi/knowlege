import { Component } from '@angular/core';

@Component({
  selector: 'sidebar',
  templateUrl : '../../sidebar.html',
})
export class sidebarComponent  { }
