import { Component } from '@angular/core';

@Component({
  selector: 'my-content',
  templateUrl: '../../../content1.html',
})
export class contentComponent  {  }
