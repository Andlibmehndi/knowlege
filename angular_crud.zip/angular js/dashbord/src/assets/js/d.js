type = ['','info','success','warning','danger'];

$().ready(function(){
demo = { showNotification: function(from, align){
    	color = Math.floor((Math.random() * 4) + 1);

    	$.notify({
        	icon: "ti-instagram",
        	message: "Welcome to <b>OUR SITE</b>."

        },{
            type: type[color],
            timer: 100,
            placement: {
                from: from,
                align: align
            }
        });
	}

}

});