import { Component } from '@angular/core';

@Component({
  selector: 'my-testComponent',
  template: `<h1>Hello {{name}}</h1>`,
})
export class testComponent  { name = 'test Component'; }