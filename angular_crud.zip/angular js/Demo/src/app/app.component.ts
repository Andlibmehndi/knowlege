import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  //styleUrls : ["../../css/bootstrap.css"],
  template: `
  <form action="/action_page.php">
  <div class="form-group">
    <label for="email">Email address:</label>
    <input  #email (keyup)="0" type="email" class="form-control" id="email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input #pass (keyup)="0" type="password" class="form-control" id="pwd">
  </div>
  <div class="checkbox">
    <label><input  type="checkbox" value="false"> Remember me</label>
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>
<div class="panel panel-success">{{email.value}}</div>
<div class="panel panel-success"><p>{{pass.value}}</p></div>

             `,
             
             
})
export class AppComponent  { 
  name = 'App Module';
  value = '';
  update(value: string) { this.value = value; } 
}
// <input #box (keyup)="0">
//     <p>{{box.value}}</p>
// (16:51) Sanjana Modi : write in a class:- value = '';
//   update(value: string) { this.value = value; }