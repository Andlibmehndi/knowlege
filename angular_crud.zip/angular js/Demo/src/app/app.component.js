"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        this.name = 'App Module';
        this.value = '';
    }
    AppComponent.prototype.update = function (value) { this.value = value; };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        //styleUrls : ["../../css/bootstrap.css"],
        template: "\n  <form action=\"/action_page.php\">\n  <div class=\"form-group\">\n    <label for=\"email\">Email address:</label>\n    <input  #email (keyup)=\"0\" type=\"email\" class=\"form-control\" id=\"email\">\n  </div>\n  <div class=\"form-group\">\n    <label for=\"pwd\">Password:</label>\n    <input #pass (keyup)=\"0\" type=\"password\" class=\"form-control\" id=\"pwd\">\n  </div>\n  <div class=\"checkbox\">\n    <label><input  type=\"checkbox\" value=\"false\"> Remember me</label>\n  </div>\n  <button type=\"submit\" class=\"btn btn-default\">Submit</button>\n</form>\n<div class=\"panel panel-success\">{{email.value}}</div>\n<div class=\"panel panel-success\"><p>{{pass.value}}</p></div>\n\n             ",
    })
], AppComponent);
exports.AppComponent = AppComponent;
// <input #box (keyup)="0">
//     <p>{{box.value}}</p>
// (16:51) Sanjana Modi : write in a class:- value = '';
//   update(value: string) { this.value = value; } 
//# sourceMappingURL=app.component.js.map