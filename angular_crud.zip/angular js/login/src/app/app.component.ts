import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: `./../login.html`,
})
export class AppComponent  { 
  data = {};
  formSubmit(){
    if (this.data.Email=="admin" && this.data.password == "admin"){
      console.log("login");
      console.log(this.data.Email);
    }
    else
    {
      console.log("ERRORRRRR............");
    }
   }
}
