import { Component } from '@angular/core';

@Component({
  selector: 'my-pageNotFound',
  template: `Sorry ! Page not found..`,
})
export class pageNotFound  
{ 
}
