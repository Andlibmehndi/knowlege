import { Component } from '@angular/core';

@Component({
  selector: 'my-second',
  template: `Hello from second component..`,
})
export class SecondClass  
{ 
}
