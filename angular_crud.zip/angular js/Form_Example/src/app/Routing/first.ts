import { Component } from '@angular/core';

@Component({
  selector: 'my-first',
  template: `Hello from first component..`,
})
export class FirstClass  
{ 
}
