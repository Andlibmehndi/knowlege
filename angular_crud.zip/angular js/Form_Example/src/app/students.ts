export class Student
{
    constructor(
        public studentId: number,
        public studentName: string,
        public studentRollno: number,
        public studentAddress: string
    ){ }
}