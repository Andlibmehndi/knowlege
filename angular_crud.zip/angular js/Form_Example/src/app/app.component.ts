import { Component } from '@angular/core';
//import { StudentList } from "./Student/studentlist";

@Component({
  selector: 'my-app',
  //template: `<student-form> </student-form>`,
  
  templateUrl: `./Navigation/nav.html`,
})
export class AppComponent  
{ 
  
}
