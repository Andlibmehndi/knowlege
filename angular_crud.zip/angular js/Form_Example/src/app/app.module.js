"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var app_component_1 = require("./app.component");
var forms_1 = require("@angular/forms");
var studentform_component_1 = require("./studentform.component");
var studentlist_1 = require("./Student/studentlist");
var first_1 = require("./Routing/first");
var second_1 = require("./Routing/second");
var router_1 = require("@angular/router");
var PageNotFound_1 = require("./Routing/PageNotFound");
var CheckBox_1 = require("./Student/CheckBox");
var fileUpload_1 = require("./FileUpload/fileUpload");
var appRoutes = [
    { path: 'FirstClass', component: first_1.FirstClass },
    { path: 'SecondClass', component: second_1.SecondClass },
    { path: 'StudentList', component: studentlist_1.StudentList },
    { path: 'CheckBox', component: CheckBox_1.CheckBox },
    { path: '**', component: PageNotFound_1.pageNotFound },
];
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, router_1.RouterModule.forRoot(appRoutes)],
        declarations: [app_component_1.AppComponent, studentform_component_1.StudentFormComponent, studentlist_1.StudentList, first_1.FirstClass, second_1.SecondClass, PageNotFound_1.pageNotFound, CheckBox_1.CheckBox],
        bootstrap: [app_component_1.AppComponent],
        providers: [fileUpload_1.Uploader]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map