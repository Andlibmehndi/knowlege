"use strict";
var Student = (function () {
    function Student(studentId, studentName, studentRollno, studentAddress) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentRollno = studentRollno;
        this.studentAddress = studentAddress;
    }
    return Student;
}());
exports.Student = Student;
//# sourceMappingURL=students.js.map