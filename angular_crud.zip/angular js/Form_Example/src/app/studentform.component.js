"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var students_1 = require("./students");
var StudentFormComponent = (function () {
    function StudentFormComponent() {
        this.model = new students_1.Student(1, "Dhruv", 10, "Ahmedabad");
    }
    return StudentFormComponent;
}());
StudentFormComponent = __decorate([
    core_1.Component({
        selector: 'student-form',
        templateUrl: './studentForm.html'
    })
], StudentFormComponent);
exports.StudentFormComponent = StudentFormComponent;
//# sourceMappingURL=studentform.component.js.map