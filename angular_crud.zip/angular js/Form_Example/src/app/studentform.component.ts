import { Component } from '@angular/core';
import { Student } from './students';

@Component ({
    selector: 'student-form',
    templateUrl: './studentForm.html'
 })

 export class StudentFormComponent {
    model = new Student(1,"Dhruv", 10, "Ahmedabad");
 }