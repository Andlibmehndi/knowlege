import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  //template: `<student-form> </student-form>`,
  
  templateUrl: `./Navigation/nav.html`,
})
export class Uploader  
{ 
  
}
