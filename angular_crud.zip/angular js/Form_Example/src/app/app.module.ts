import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import { FormsModule } from '@angular/forms';
import { StudentFormComponent } from "./studentform.component";
import { StudentList } from "./Student/studentlist";

import { FirstClass } from "./Routing/first";
import { SecondClass } from "./Routing/second";
import { RouterModule, Routes } from '@angular/router';
import { pageNotFound } from "./Routing/PageNotFound";
import { CheckBox } from "./Student/CheckBox";
import { Uploader } from "./FileUpload/fileUpload";


const appRoutes: Routes = [
  { path: 'FirstClass', component: FirstClass },
  { path: 'SecondClass', component: SecondClass },
  { path: 'StudentList', component: StudentList },
  { path: 'CheckBox', component: CheckBox },
  { path: '**', component: pageNotFound },
];


@NgModule({
  imports:      [ BrowserModule, FormsModule, RouterModule.forRoot(appRoutes)],
  declarations: [ AppComponent, StudentFormComponent, StudentList, FirstClass, SecondClass, pageNotFound, CheckBox ],
  bootstrap:    [ AppComponent ],
  providers:    [ Uploader ]
})
export class AppModule { }
