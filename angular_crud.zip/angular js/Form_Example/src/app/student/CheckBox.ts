import { Component } from '@angular/core';
//import { StudentList } from "./Student/studentlist";

@Component({
  selector: 'my-checkbox',
  
  templateUrl: `./checkbox.html`,
})
export class CheckBox
{ 
    title:string;
    names:any;
    selectedAll: any;

    log = '';
    
    constructor()
    {       
        this.title = "Select or Deselect all";
        this.names = [
            { name: 'Dhruv', selected: false },
            { name: 'Abraham', selected: false },
            { name: 'Anil', selected: false },
            { name: 'Sam', selected: false },
            { name: 'Natasha', selected: false },
            { name: 'Marry', selected: false },
            { name: 'Zian', selected: false },
            { name: 'karan', selected: false },
        ]
    }

    selectAll() {
        for (var i = 0; i < this.names.length; i++) {
          this.names[i].selected = this.selectedAll;
        }
      }
      checkIfAllSelected() {
        this.selectedAll = this.names.every(function(item:any) {
            return item.selected == true;
          })
      }

      logCheckbox(element: HTMLInputElement): void 
      {
        this.log += `Checkbox ${element.value} was ${element.checked ? '' : 'un'}checked\n`;
      }
}
