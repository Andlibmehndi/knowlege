"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
//import { StudentList } from "./Student/studentlist";
var CheckBox = (function () {
    function CheckBox() {
        this.log = '';
        this.title = "Select or Deselect all";
        this.names = [
            { name: 'Dhruv', selected: false },
            { name: 'Abraham', selected: false },
            { name: 'Anil', selected: false },
            { name: 'Sam', selected: false },
            { name: 'Natasha', selected: false },
            { name: 'Marry', selected: false },
            { name: 'Zian', selected: false },
            { name: 'karan', selected: false },
        ];
    }
    CheckBox.prototype.selectAll = function () {
        for (var i = 0; i < this.names.length; i++) {
            this.names[i].selected = this.selectedAll;
        }
    };
    CheckBox.prototype.checkIfAllSelected = function () {
        this.selectedAll = this.names.every(function (item) {
            return item.selected == true;
        });
    };
    CheckBox.prototype.logCheckbox = function (element) {
        this.log += "Checkbox " + element.value + " was " + (element.checked ? '' : 'un') + "checked\n";
    };
    return CheckBox;
}());
CheckBox = __decorate([
    core_1.Component({
        selector: 'my-checkbox',
        templateUrl: "./checkbox.html",
    }),
    __metadata("design:paramtypes", [])
], CheckBox);
exports.CheckBox = CheckBox;
//# sourceMappingURL=CheckBox.js.map