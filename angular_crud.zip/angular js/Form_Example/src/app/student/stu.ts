export class Student
{
    studentId: number;
    studentName: string;
    studentRollno: number;
    studentAddress: string;

    constructor(studentId:number, studentName:string, studentRollno:number, studentAddress:string)
    {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentRollno = studentRollno;
        this.studentAddress = studentAddress;
    }
}