import {Component} from '@angular/core';
import {Student} from './stu';

@Component({
    selector: 'student-list',
    templateUrl: './student-list.html'
})

export class StudentList
{
    students: Array<Student>
    reset:any;

    constructor()
    {
        this.students = [];
    }

    addStudent(studentId:number, studentName:string, studentRollno:number, studentAddress:string)
    {
        var x = document.forms["form1"]["id"].value;
        var x1 = document.forms["form1"]["name1"].value;
        var x2 = document.forms["form1"]["rollno1"].value;
        var x3 = document.forms["form1"]["address1"].value;
        if(x == "")
        {
            alert("Enter ID...");
            return false;
        }
        else if(x1 == "")
        {
            alert("Enter Name...");
            return false;
        }
        else if(x2 == "")
        {
            alert("Enter RollNo...");
             return false;
        }
        else if(x3 == "")
         {
            alert("Enter Address...");
            return false;
        }
        else
        {
            let student = new Student(studentId, studentName, studentRollno, studentAddress);
            this.students.push(student);
            document.getElementById("form1").reset();
        }    
    }

    deleteStudent(student:Student)
    {
        var x = confirm("Are you sure you want to delete?");
        if (x)
        {
            let index = this.students.indexOf(student);
            this.students.splice(index,1);
        }
        else
        {
            return false;
        }   
    }

    // clearStudent(student: Student) 
    // {
    //     document.getElementById("form1").reset();
    // }

    Status : boolean = false;
    clicked(event:any)
    {
        this.Status = true;
    }
}

