"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var stu_1 = require("./stu");
var StudentList = (function () {
    function StudentList() {
        // clearStudent(student: Student) 
        // {
        //     document.getElementById("form1").reset();
        // }
        this.Status = false;
        this.students = [];
    }
    StudentList.prototype.addStudent = function (studentId, studentName, studentRollno, studentAddress) {
        var x = document.forms["form1"]["id"].value;
        var x1 = document.forms["form1"]["name1"].value;
        var x2 = document.forms["form1"]["rollno1"].value;
        var x3 = document.forms["form1"]["address1"].value;
        if (x == "") {
            alert("Enter ID...");
            return false;
        }
        else if (x1 == "") {
            alert("Enter Name...");
            return false;
        }
        else if (x2 == "") {
            alert("Enter RollNo...");
            return false;
        }
        else if (x3 == "") {
            alert("Enter Address...");
            return false;
        }
        else {
            var student = new stu_1.Student(studentId, studentName, studentRollno, studentAddress);
            this.students.push(student);
            document.getElementById("form1").reset();
        }
    };
    StudentList.prototype.deleteStudent = function (student) {
        var x = confirm("Are you sure you want to delete?");
        if (x) {
            var index = this.students.indexOf(student);
            this.students.splice(index, 1);
        }
        else {
            return false;
        }
    };
    StudentList.prototype.clicked = function (event) {
        this.Status = true;
    };
    return StudentList;
}());
StudentList = __decorate([
    core_1.Component({
        selector: 'student-list',
        templateUrl: './student-list.html'
    }),
    __metadata("design:paramtypes", [])
], StudentList);
exports.StudentList = StudentList;
//# sourceMappingURL=studentlist.js.map