import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './dashbord.html'
})
export class AppComponent  { name = 'Angular'; }
