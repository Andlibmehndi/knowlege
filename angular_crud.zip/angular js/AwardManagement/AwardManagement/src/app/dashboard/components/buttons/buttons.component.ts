import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'buttons-cmp',
    templateUrl: 'buttons.component.html'
})

export class ButtonsComponent{}
