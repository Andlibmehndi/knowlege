declare function initCollapseArea():void;
export = initCollapseArea;
