declare function initSliders():void;
export = initSliders;
