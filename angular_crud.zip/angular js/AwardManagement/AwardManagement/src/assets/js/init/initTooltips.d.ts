declare function initTooltips():void;
export = initTooltips;
