declare function initVectorMap():void;
export = initVectorMap;
