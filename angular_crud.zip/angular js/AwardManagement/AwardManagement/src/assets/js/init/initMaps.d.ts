declare function initMaps():void;
export = initMaps;
